includeTargets << grailsScript("_GrailsInit")

target(@gant.target.name@: "The description of the script goes here!") {
    // TODO: Implement script here
}

setDefaultTarget(@gant.target.name@)
