package net.okjsp

import grails.transaction.Transactional

@Transactional
class RecruitService {

    def create() {



    }
}
