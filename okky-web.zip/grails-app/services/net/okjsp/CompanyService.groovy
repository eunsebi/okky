package net.okjsp

import grails.transaction.Transactional

@Transactional
class CompanyService {

    def serviceMethod() {

    }
}
