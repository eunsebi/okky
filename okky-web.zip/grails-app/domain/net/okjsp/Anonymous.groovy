package net.okjsp

class Anonymous {

    User user
    Article article
    Content content
    ContentType type

    static constraints = {
    }
}
