package net.okjsp

/**
 * Created by langerhans on 2014. 9. 20..
 */
public enum ContentType {
    ARTICLE, NOTE
}