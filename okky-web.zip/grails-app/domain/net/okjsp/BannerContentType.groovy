package net.okjsp

enum BannerContentType {
    IMAGE_FILE, IMAGE_URL, TAG
}