package net.okjsp

class ConfirmEmail {

    User user
    String email
    String securedKey

    Date dateExpired

    static constraints = {
    }
}
