package net.okjsp

class SpamWord {
    
    String text

    static constraints = {
    }
    
    static mapping = {
        cache true
    }
}
