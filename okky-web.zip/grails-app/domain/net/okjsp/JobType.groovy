package net.okjsp

/**
 * Created by langerhans on 2016. 9. 29..
 */
enum JobType {
    FULLTIME, CONTRACT
}