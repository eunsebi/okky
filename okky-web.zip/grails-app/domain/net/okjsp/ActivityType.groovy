package net.okjsp

/**
 * Created by langerhans on 2014. 9. 20..
 */
public enum ActivityType {
    POSTED, SCRAPED, NOTED, NOTED_AFTER, SOLVED,
    ASSENTED_ARTICLE, ASSENTED_NOTE, DISSENTED_ARTICLE, DISSENTED_NOTE
}