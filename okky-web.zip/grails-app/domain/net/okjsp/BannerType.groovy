package net.okjsp

/**
 * Created by langerhans on 14. 11. 6..
 */
public enum BannerType {
    MAIN, CONTENT, MAIN_RIGHT_TOP, SUB_RIGHT_TOP, JOBS_TOP, MAIN_BLOCK, MAIN_RIGHT_BOTTOM, SUB_RIGHT_BOTTOM,
}