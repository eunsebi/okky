package net.okjsp

class AutoPasswordOID {

    User user
    String oid
    String userNo

    static constraints = {
    }
}
