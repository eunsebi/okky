package net.okjsp

enum JobPayType {
    M_20_30, M_30_40, M_40_50, M_50_60, M_60_70, M_70_80, M_80_90, M_90_OVER,
    Y_20_30, Y_30_40, Y_40_50, Y_50_60, Y_60_70, Y_70_80, Y_80_90, Y_90_OVER
}