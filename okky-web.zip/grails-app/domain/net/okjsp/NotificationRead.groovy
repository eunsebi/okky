package net.okjsp

class NotificationRead {

    Avatar avatar
    Date lastRead = new Date()

    static constraints = {
    }
}
