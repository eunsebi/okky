package net.okjsp

class Resume {

    static hasMany = [carrers: Career]

    static constraints = {
    }
}
