package net.okjsp

class TagSimilarText {

    String text

    static belongsTo = [tag: Tag]

    static constraints = {
    }
}
