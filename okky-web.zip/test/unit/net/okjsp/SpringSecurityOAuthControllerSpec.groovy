package net.okjsp

import grails.test.mixin.TestFor
import net.okjsp.SpringSecurityOAuthController
import spock.lang.Specification

/**
 * See the API for {@link grails.test.mixin.web.ControllerUnitTestMixin} for usage instructions
 */
@TestFor(SpringSecurityOAuthController)
class SpringSecurityOAuthControllerSpec extends Specification {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
    }
}
